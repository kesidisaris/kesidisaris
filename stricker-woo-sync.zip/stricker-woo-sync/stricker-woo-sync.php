<?php
/**
 * Plugin Name: Stricker Sync for WooCommerce
 * Description: Επιλέγετε κατηγορίες ή μεμονωμένα προϊόντα από το Stricker Europe web service και τα συγχρονίζετε στο WooCommerce (προϊόντα, χρώματα/παραλλαγές, εικόνες, τιμές, stock).
 * Version:     1.0.1
 * Requires PHP: 7.4
 * Author:      Kyklos
 * Text Domain: stricker-woo-sync
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

define( 'SWS_VERSION', '1.0.1' );
define( 'SWS_DIR', plugin_dir_path( __FILE__ ) );
define( 'SWS_URL', plugin_dir_url( __FILE__ ) );

require_once SWS_DIR . 'includes/class-util.php';
require_once SWS_DIR . 'includes/class-settings.php';
require_once SWS_DIR . 'includes/class-api.php';
require_once SWS_DIR . 'includes/class-catalog.php';
require_once SWS_DIR . 'includes/class-importer.php';
require_once SWS_DIR . 'includes/class-admin.php';

add_action( 'plugins_loaded', function () {
	if ( ! class_exists( 'WooCommerce' ) ) {
		add_action( 'admin_notices', function () {
			echo '<div class="notice notice-error"><p>Το <strong>Stricker Sync</strong> χρειάζεται το WooCommerce ενεργό.</p></div>';
		} );
		return;
	}
	SWS_Admin::init();
} );
