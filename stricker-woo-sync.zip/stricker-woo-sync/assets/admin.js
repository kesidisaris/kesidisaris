(function ($) {
	'use strict';

	var S = { prods: {}, nodes: {}, sel: {}, view: [] };
	var MAX_ROWS = 400, CHUNK = 2;

	function api(action, data) {
		return $.post(SWS.ajax, $.extend({ action: action, _n: SWS.nonce }, data));
	}
	function esc(s) { return $('<div>').text(s == null ? '' : s).html(); }
	function count() { return Object.keys(S.sel).length; }
	function log(t) {
		var $l = $('#sws-log').show();
		$l.append(document.createTextNode(t + '\n'));
		$l.scrollTop($l[0].scrollHeight);
	}

	/* ---- Δέντρο ---- */
	var seq = 0;
	function index(nodes) {
		var all = [];
		nodes.forEach(function (n) {
			n._id = 'n' + (++seq);
			S.nodes[n._id] = n;
			var refs = (n.refs || []).slice();
			n.children = n.children || [];
			refs = refs.concat(index(n.children));
			n._refs = refs.filter(function (v, i, a) { return a.indexOf(v) === i; });
			all = all.concat(n._refs);
		});
		return all;
	}
	function treeHtml(nodes) {
		var h = '<ul>';
		nodes.forEach(function (n) {
			var kids = n.children.length;
			h += '<li><div class="sws-node"><span class="sws-tg">' + (kids ? '▸' : '') + '</span>' +
				'<input type="checkbox" class="sws-cat" data-id="' + n._id + '"> ' +
				'<a href="#" class="sws-open" data-id="' + n._id + '">' + esc(n.name) + '</a> ' +
				'<span class="cnt">(' + n._refs.length + ')</span></div>' +
				(kids ? treeHtml(n.children) : '') + '</li>';
		});
		return h + '</ul>';
	}

	function refreshChecks() {
		$('.sws-cat').each(function () {
			var refs = S.nodes[$(this).data('id')]._refs, n = 0;
			refs.forEach(function (r) { if (S.sel[r]) n++; });
			this.checked = refs.length > 0 && n === refs.length;
			this.indeterminate = n > 0 && n < refs.length;
		});
		$('#sws-list input[data-ref]').each(function () { this.checked = !!S.sel[$(this).data('ref')]; });
		var c = count();
		$('#sws-import').prop('disabled', !c).text('Συγχρονισμός επιλεγμένων (' + c + ')');
	}

	/* ---- Λίστα προϊόντων ---- */
	function showList(refs, title) {
		S.view = refs;
		$('#sws-list-title').text(title + ' — ' + refs.length + ' προϊόντα');
		var h = '';
		refs.slice(0, MAX_ROWS).forEach(function (r) {
			var p = S.prods[r]; if (!p) return;
			h += '<label class="sws-row"><input type="checkbox" data-ref="' + esc(r) + '">' +
				(p[1] ? '<img loading="lazy" src="' + esc(p[1]) + '">' : '<span class="ph"></span>') +
				'<span class="ref">' + esc(r) + '</span><span>' + esc(p[0]) +
				(p[2] > 1 ? ' <em>(' + p[2] + ' χρώματα)</em>' : '') + '</span></label>';
		});
		if (refs.length > MAX_ROWS) h += '<p>Εμφανίζονται τα πρώτα ' + MAX_ROWS + '. Χρησιμοποιήστε την αναζήτηση για να περιορίσετε.</p>';
		$('#sws-list').html(h || '<p>Κανένα προϊόν.</p>');
		refreshChecks();
	}

	function load(refresh) {
		$('#sws-load').prop('disabled', true).text('Φόρτωση… (μπορεί να πάρει λίγο)');
		api('sws_catalog', { refresh: refresh ? 1 : 0 }).done(function (r) {
			if (!r.success) { alert(r.data); return; }
			var d = r.data;
			S.prods = d.products; S.nodes = {}; seq = 0;
			index(d.tree);
			$('#sws-tree').html(treeHtml(d.tree));
			$('#sws-built').text('Τελευταία ενημέρωση καταλόγου: ' + d.built + ' • ' + Object.keys(S.prods).length + ' προϊόντα');
			$('#sws-app').show();
			showList(Object.keys(S.prods), 'Όλα τα προϊόντα');
		}).fail(function () { alert('Αποτυχία αιτήματος.'); })
			.always(function () { $('#sws-load').prop('disabled', false).text('Φόρτωση / Ανανέωση καταλόγου'); });
	}

	/* ---- Εισαγωγή ---- */
	function runImport() {
		var refs = Object.keys(S.sel), i = 0, ok = 0, err = 0;
		if (!refs.length) return;
		$('#sws-import, #sws-load, #sws-sync-live').prop('disabled', true);
		$('#sws-log').text('').show();
		$('#sws-progress').show().find('div').css('width', 0);
		(function next() {
			if (i >= refs.length) {
				log('\nΤέλος: ' + ok + ' επιτυχή, ' + err + ' με σφάλμα.');
				$('#sws-load, #sws-sync-live').prop('disabled', false);
				refreshChecks();
				return;
			}
			var chunk = refs.slice(i, i + CHUNK); i += CHUNK;
			api('sws_import', { refs: chunk }).done(function (r) {
				if (!r.success) { err += chunk.length; log('ΣΦΑΛΜΑ: ' + r.data); return; }
				r.data.results.forEach(function (x) {
					if (x.status === 'error') { err++; } else { ok++; delete S.sel[x.ref]; }
					log('[' + x.status + '] ' + x.ref + ' — ' + x.msg);
				});
			}).fail(function () { err += chunk.length; log('Αποτυχία αιτήματος για: ' + chunk.join(', ')); })
				.always(function () {
					$('#sws-progress div').css('width', Math.min(100, i / refs.length * 100) + '%');
					next();
				});
		})();
	}

	function syncLive() {
		if (!confirm('Θα ενημερωθούν τιμές και stock όλων των εισηγμένων προϊόντων. Συνέχεια;')) return;
		$('#sws-log').text('').show();
		$('#sws-progress').show().find('div').css('width', 0);
		$('#sws-import, #sws-load, #sws-sync-live').prop('disabled', true);
		(function next(offset) {
			api('sws_sync_live', { offset: offset }).done(function (r) {
				if (!r.success) { log('ΣΦΑΛΜΑ: ' + r.data); return end(); }
				var d = r.data;
				$('#sws-progress div').css('width', (d.total ? d.done / d.total * 100 : 100) + '%');
				log('Ενημερώθηκαν ' + d.done + ' / ' + d.total);
				if (d.done < d.total) next(offset + 40); else end();
			}).fail(function () { log('Αποτυχία αιτήματος.'); end(); });
		})(0);
		function end() { $('#sws-load, #sws-sync-live').prop('disabled', false); refreshChecks(); log('Ολοκληρώθηκε.'); }
	}

	$(function () {
		/* Διαγνωστικά */
		$('.sws-dbg').on('click', function () {
			var $o = $('#sws-dbg-out').text('Φόρτωση…');
			api('sws_debug', { ep: $(this).data('ep') }).done(function (r) { $o.text(r.data); });
		});

		if (!$('#sws-load').length) return;

		$('#sws-load').on('click', function () { load(true); });
		$('#sws-import').on('click', runImport);
		$('#sws-sync-live').on('click', syncLive);

		$('#sws-tree').on('click', '.sws-tg', function () { $(this).text($(this).closest('li').toggleClass('open').hasClass('open') ? '▾' : '▸'); });
		$('#sws-tree').on('click', '.sws-open', function (e) {
			e.preventDefault();
			$('.sws-open').removeClass('active'); $(this).addClass('active');
			var n = S.nodes[$(this).data('id')];
			$('#sws-search').val('');
			showList(n._refs, n.name);
		});
		$('#sws-tree').on('change', '.sws-cat', function () {
			var on = this.checked;
			S.nodes[$(this).data('id')]._refs.forEach(function (r) { if (on) S.sel[r] = 1; else delete S.sel[r]; });
			refreshChecks();
		});
		$('#sws-list').on('change', 'input[data-ref]', function () {
			if (this.checked) S.sel[$(this).data('ref')] = 1; else delete S.sel[$(this).data('ref')];
			refreshChecks();
		});
		$('#sws-sel-visible').on('click', function () {
			S.view.slice(0, MAX_ROWS).forEach(function (r) { S.sel[r] = 1; });
			refreshChecks();
		});
		$('#sws-clear').on('click', function () { S.sel = {}; refreshChecks(); });

		var t;
		$('#sws-search').on('input', function () {
			var q = this.value.trim().toLowerCase();
			clearTimeout(t);
			t = setTimeout(function () {
				if (!q) { showList(Object.keys(S.prods), 'Όλα τα προϊόντα'); return; }
				var res = Object.keys(S.prods).filter(function (r) {
					return r.toLowerCase().indexOf(q) > -1 || String(S.prods[r][0]).toLowerCase().indexOf(q) > -1;
				});
				showList(res, 'Αποτελέσματα αναζήτησης');
			}, 250);
		});

		load(false); // φόρτωση από cache (ή πρώτη λήψη)
	});
})(jQuery);
