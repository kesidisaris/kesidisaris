<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Βοηθητικές συναρτήσεις. Τα ονόματα πεδίων του web service διαβάζονται "ανεκτικά"
 * (case-insensitive, με λίστα εναλλακτικών) ώστε να αντέχουν μικροδιαφορές στο JSON.
 */
class SWS_Util {

	public static function pick( $arr, $keys, $default = '' ) {
		if ( ! is_array( $arr ) ) {
			return $default;
		}
		$lower = array();
		foreach ( $arr as $k => $v ) {
			$lower[ strtolower( (string) $k ) ] = $v;
		}
		foreach ( (array) $keys as $k ) {
			$lk = strtolower( $k );
			if ( isset( $lower[ $lk ] ) && ! is_array( $lower[ $lk ] ) && trim( (string) $lower[ $lk ] ) !== '' ) {
				return trim( (string) $lower[ $lk ] );
			}
		}
		return $default;
	}

	public static function is_list( $a ) {
		if ( ! is_array( $a ) ) {
			return false;
		}
		if ( ! $a ) {
			return true;
		}
		return array_keys( $a ) === range( 0, count( $a ) - 1 );
	}

	/** Βρίσκει την πρώτη λίστα από αντικείμενα μέσα σε μια απάντηση JSON. */
	public static function extract_list( $json ) {
		if ( ! is_array( $json ) ) {
			return array();
		}
		if ( self::is_list( $json ) ) {
			return $json;
		}
		foreach ( $json as $v ) {
			if ( is_array( $v ) && $v && self::is_list( $v ) && is_array( reset( $v ) ) ) {
				return $v;
			}
		}
		foreach ( $json as $v ) {
			if ( is_array( $v ) ) {
				$r = self::extract_list( $v );
				if ( $r ) {
					return $r;
				}
			}
		}
		return array();
	}

	/** Κανονικοποιεί ένα URL εικόνας (protocol-relative, σχετικό, κενά). */
	public static function norm_url( $u ) {
		$u = trim( str_replace( '\\/', '/', (string) $u ) );
		$u = str_replace( ' ', '%20', $u );
		if ( 0 === strpos( $u, '//' ) ) {
			return 'https:' . $u;
		}
		if ( preg_match( '#^https?://#i', $u ) ) {
			return $u;
		}
		return 'https://www.stricker-europe.com/' . ltrim( $u, '/' );
	}

	/**
	 * Μαζεύει όλα τα URL εικόνων από ένα στοιχείο. Δέχεται:
	 *  - οποιοδήποτε URL με κατάληξη εικόνας (και μέσα σε query string),
	 *  - τιμές σε πεδία με όνομα τύπου image/photo/picture/img/foto/thumb (ακόμη και χωρίς κατάληξη),
	 *  - σχετικά και protocol-relative URL.
	 */
	public static function images( $arr ) {
		$out  = array();
		$ext  = '#\.(jpe?g|png|webp|gif)(\?.*)?$|\.(jpe?g|png|webp|gif)(\?|&|$)#i';
		$walk = function ( $v, $key ) use ( &$walk, &$out, $ext ) {
			if ( is_array( $v ) ) {
				foreach ( $v as $k => $x ) {
					$walk( $x, is_string( $k ) ? $k : $key );
				}
				return;
			}
			if ( ! is_string( $v ) ) {
				return;
			}
			$t = trim( $v );
			if ( '' === $t || strlen( $t ) > 1000 || preg_match( '/\s{2,}|[<>]/', $t ) ) {
				return;
			}
			$img_key = (bool) preg_match( '/(image|img|photo|foto|picture|pic|thumb)/i', (string) $key );
			$is_url  = (bool) preg_match( '#^(https?:)?//\S+$#i', $t );
			$has_ext = (bool) preg_match( $ext, $t );
			if ( ( $is_url && ( $has_ext || $img_key ) ) || ( $img_key && ! preg_match( '/\s/', $t ) && ( $has_ext || false !== strpos( $t, '/' ) ) ) ) {
				$out[] = self::norm_url( $t );
			}
		};
		$walk( $arr, '' );
		return array_values( array_unique( $out ) );
	}

	public static function num( $v ) {
		if ( is_numeric( $v ) ) {
			return (float) $v;
		}
		$v = str_replace( ',', '.', preg_replace( '/[^0-9,.\-]/', '', (string) $v ) );
		return is_numeric( $v ) ? (float) $v : null;
	}
}
