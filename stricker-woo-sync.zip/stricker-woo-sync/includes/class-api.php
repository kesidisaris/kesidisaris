<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Client για το Stricker REST web service (αντίστοιχο του StrickerRestClient.php).
 */
class SWS_API {

	private $s;

	// Endpoints όπως στο επίσημο παράδειγμα.
	const EP = array(
		'productsTree' => 'productsTree',
		'products'     => 'products',
		'optionals'    => 'optionals',
		'stocks'       => 'stocks',
		'prices'       => 'CatalogPrices',
		'types'        => 'ProductTypes',
		'colors'       => 'colors',
	);

	public function __construct() {
		$this->s = SWS_Settings::get();
	}

	private function base() {
		return 'http' === $this->s['protocol']
			? 'http://ws.stricker-europe.com/api/v1/'
			: 'https://ws.stricker-europe.com/api/v1SSL/';
	}

	private function request( $endpoint, $params ) {
		$url  = $this->base() . $endpoint . '?' . http_build_query( $params );
		$resp = wp_remote_get( $url, array(
			'timeout' => 300,
			'headers' => array( 'Accept' => 'application/json' ),
		) );
		if ( is_wp_error( $resp ) ) {
			return $resp;
		}
		$code = wp_remote_retrieve_response_code( $resp );
		$json = json_decode( wp_remote_retrieve_body( $resp ), true );
		if ( $code >= 400 || null === $json ) {
			return new WP_Error( 'sws_http', sprintf( 'Σφάλμα web service (HTTP %d) στο %s', $code, $endpoint ) );
		}
		return $json;
	}

	public function token( $force = false ) {
		if ( ! $force ) {
			$t = get_transient( 'sws_token' );
			if ( $t ) {
				return $t;
			}
		}
		if ( '' === $this->s['access_key'] ) {
			return new WP_Error( 'sws_key', 'Δεν έχει οριστεί Access Key.' );
		}
		$r = $this->request( 'authenticateclient', array( 'accesskey' => $this->s['access_key'] ) );
		if ( is_wp_error( $r ) ) {
			return $r;
		}
		$tok = SWS_Util::pick( $r, array( 'Token' ) );
		if ( '' === $tok ) {
			return new WP_Error( 'sws_auth', 'Αποτυχία authentication – ελέγξτε το Access Key.' );
		}
		set_transient( 'sws_token', $tok, 20 * MINUTE_IN_SECONDS );
		return $tok;
	}

	/** Κλήση endpoint με token (και ένα retry με νέο token). */
	public function get( $key ) {
		$endpoint = self::EP[ $key ] ?? $key;
		$with_lang = in_array( $key, array( 'productsTree', 'products', 'optionals', 'colors', 'stocks' ), true );

		for ( $try = 0; $try < 2; $try++ ) {
			$tok = $this->token( $try > 0 );
			if ( is_wp_error( $tok ) ) {
				return $tok;
			}
			$params = array( 'token' => $tok );
			if ( $with_lang ) {
				$params['lang'] = $this->s['language'];
			}
			$r = $this->request( $endpoint, $params );
			if ( ! is_wp_error( $r ) ) {
				return $r;
			}
		}
		return $r;
	}
}
