<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class SWS_Importer {

	/** Σφάλματα λήψης εικόνων του τρέχοντος import. */
	private static $img_errors = array();

	/** Εισαγωγή / ενημέρωση ενός προϊόντος Stricker (με βάση το ProdReference). */
	public static function import( $ref ) {
		try {
			return self::do_import( $ref );
		} catch ( Exception $e ) {
			return array( 'ref' => $ref, 'status' => 'error', 'msg' => $e->getMessage() );
		}
	}

	private static function do_import( $ref ) {
		self::$img_errors = array();
		$cat = SWS_Catalog::get();
		if ( is_wp_error( $cat ) || empty( $cat['products'][ $ref ] ) ) {
			return array( 'ref' => $ref, 'status' => 'error', 'msg' => 'Δεν βρέθηκε στον κατάλογο.' );
		}
		$s        = SWS_Settings::get();
		$p        = $cat['products'][ $ref ];
		$variants = $cat['optionals'][ $ref ] ?? array();
		$live     = SWS_Catalog::live();
		$is_var   = count( $variants ) > 1;

		$id      = wc_get_product_id_by_sku( $ref );
		$created = ! $id;

		if ( $id ) {
			$prod = wc_get_product( $id );
			if ( $is_var && 'variable' !== $prod->get_type() ) {
				wp_set_object_terms( $id, 'variable', 'product_type' );
				$prod = new WC_Product_Variable( $id );
			} elseif ( ! $is_var && 'variable' === $prod->get_type() ) {
				wp_set_object_terms( $id, 'simple', 'product_type' );
				$prod = new WC_Product_Simple( $id );
			}
		} else {
			$prod = $is_var ? new WC_Product_Variable() : new WC_Product_Simple();
			$prod->set_sku( $ref );
			$prod->set_status( $s['status'] );
		}

		$prod->set_name( $p['name'] );
		$prod->set_description( $p['desc'] );
		$prod->set_short_description( $p['short'] );
		$prod->set_category_ids( self::category_ids( $ref, $cat ) );
		$prod->update_meta_data( '_sws_ref', $ref );
		if ( $p['brand'] ) {
			$prod->update_meta_data( '_sws_brand', $p['brand'] );
		}
		$prod->update_meta_data( '_sws_last_sync', time() );

		if ( $is_var ) {
			$colors = array();
			foreach ( $variants as $v ) {
				$colors[] = self::color_of( $v );
			}
			$attr = new WC_Product_Attribute();
			$attr->set_id( 0 );
			$attr->set_name( $s['color_label'] );
			$attr->set_options( array_values( array_unique( $colors ) ) );
			$attr->set_visible( true );
			$attr->set_variation( true );
			$prod->set_attributes( array( $attr ) );
		} else {
			self::apply_live( $prod, $variants[0]['sku'] ?? $ref, $ref, $live, $s['markup'] );
		}

		$pid = $prod->save();

		// Εικόνες (μετά το πρώτο save, για να έχουμε post ID).
		if ( $s['import_images'] ) {
			$imgs = $p['images'];
			if ( ! $imgs && ! empty( $variants[0]['images'] ) ) {
				$imgs = $variants[0]['images'];
			}
			if ( $imgs ) {
				$main = self::sideload( $imgs[0], $pid );
				if ( $main ) {
					$prod->set_image_id( $main );
				}
				$gallery = array();
				foreach ( array_slice( $imgs, 1, 5 ) as $u ) {
					$a = self::sideload( $u, $pid );
					if ( $a ) {
						$gallery[] = $a;
					}
				}
				$prod->set_gallery_image_ids( $gallery );
				$prod->save();
			}
		}

		// Παραλλαγές
		if ( $is_var ) {
			$key = sanitize_title( $s['color_label'] );
			foreach ( $variants as $v ) {
				$vid = wc_get_product_id_by_sku( $v['sku'] );
				$var = $vid ? new WC_Product_Variation( $vid ) : new WC_Product_Variation();
				$var->set_parent_id( $pid );
				$var->set_attributes( array( $key => self::color_of( $v ) ) );
				$var->set_sku( $v['sku'] );
				$var->set_status( 'publish' );
				self::apply_live( $var, $v['sku'], $ref, $live, $s['markup'] );
				$vpid = $var->save();
				if ( $s['import_images'] && ! empty( $v['images'][0] ) ) {
					$a = self::sideload( $v['images'][0], $pid );
					if ( $a ) {
						$var->set_image_id( $a );
						$var->save();
					}
				}
			}
			WC_Product_Variable::sync( $pid );
		}

		$note = '';
		if ( $s['import_images'] ) {
			if ( self::$img_errors ) {
				$note = ' ⚠ εικόνες: ' . implode( ' | ', array_slice( array_unique( self::$img_errors ), 0, 2 ) );
			} elseif ( empty( $p['images'] ) && empty( $variants[0]['images'] ) ) {
				$note = ' ⚠ δεν βρέθηκε URL εικόνας στον κατάλογο (πατήστε «Ανανέωση καταλόγου»)';
			}
		}
		return array(
			'ref'    => $ref,
			'status' => $created ? 'created' : 'updated',
			'msg'    => $p['name'] . ( $is_var ? ' (' . count( $variants ) . ' χρώματα)' : '' ) . $note,
		);
	}

	private static function color_of( $v ) {
		if ( $v['color'] ) {
			return $v['color'];
		}
		$parts = explode( '-', $v['sku'], 2 );
		return $parts[1] ?? $v['sku'];
	}

	/** Τιμή & stock σε προϊόν/παραλλαγή. */
	public static function apply_live( $obj, $sku, $ref, $live, $markup ) {
		$qty = $live['stocks'][ $sku ] ?? null;
		if ( null !== $qty ) {
			$obj->set_manage_stock( true );
			$obj->set_stock_quantity( (int) $qty );
			$obj->set_stock_status( $qty > 0 ? 'instock' : 'outofstock' );
		}
		$price = $live['prices'][ $sku ] ?? ( $live['prices'][ $ref ] ?? null );
		if ( null !== $price ) {
			$obj->set_regular_price( wc_format_decimal( $price * ( 1 + (float) $markup / 100 ), 2 ) );
		}
	}

	/** Δημιουργεί (αν λείπουν) τις κατηγορίες WooCommerce από το δέντρο Stricker. */
	private static function category_ids( $ref, $cat ) {
		$ids = array();
		foreach ( $cat['refpaths'][ $ref ] ?? array() as $path ) {
			$parent = 0;
			foreach ( $path as $name ) {
				$t = term_exists( $name, 'product_cat', $parent );
				if ( ! $t ) {
					$t = wp_insert_term( $name, 'product_cat', array( 'parent' => $parent ) );
				}
				if ( is_wp_error( $t ) ) {
					$parent = 0;
					continue 2;
				}
				$parent = (int) ( is_array( $t ) ? $t['term_id'] : $t );
			}
			if ( $parent ) {
				$ids[] = $parent;
			}
		}
		return array_values( array_unique( $ids ) );
	}

	private static function sideload( $url, $post_id ) {
		$found = get_posts( array(
			'post_type'      => 'attachment',
			'post_status'    => 'inherit',
			'meta_key'       => '_sws_src',
			'meta_value'     => $url,
			'fields'         => 'ids',
			'posts_per_page' => 1,
		) );
		if ( $found ) {
			return (int) $found[0];
		}
		require_once ABSPATH . 'wp-admin/includes/file.php';
		require_once ABSPATH . 'wp-admin/includes/media.php';
		require_once ABSPATH . 'wp-admin/includes/image.php';

		$tmp = download_url( $url, 60 );
		if ( is_wp_error( $tmp ) && 0 === strpos( $url, 'https://' ) ) {
			$tmp = download_url( 'http://' . substr( $url, 8 ), 60 );
		}
		if ( is_wp_error( $tmp ) ) {
			self::$img_errors[] = $tmp->get_error_message() . ' (' . $url . ')';
			return 0;
		}
		$name = sanitize_file_name( basename( wp_parse_url( $url, PHP_URL_PATH ) ) );
		if ( ! preg_match( '/\.(jpe?g|png|webp|gif)$/i', $name ) ) {
			// Ανίχνευση τύπου από το ίδιο το αρχείο.
			$info = @getimagesize( $tmp );
			if ( ! $info ) {
				self::$img_errors[] = 'Το URL δεν επιστρέφει εικόνα (' . $url . ')';
				@unlink( $tmp );
				return 0;
			}
			$map  = array( IMAGETYPE_JPEG => 'jpg', IMAGETYPE_PNG => 'png', IMAGETYPE_GIF => 'gif', IMAGETYPE_WEBP => 'webp' );
			$name = ( $name ?: 'stricker-image' ) . '.' . ( $map[ $info[2] ] ?? 'jpg' );
		}
		$id = media_handle_sideload( array( 'name' => $name, 'tmp_name' => $tmp ), $post_id );
		if ( is_wp_error( $id ) ) {
			self::$img_errors[] = $id->get_error_message() . ' (' . $url . ')';
			@unlink( $tmp );
			return 0;
		}
		update_post_meta( $id, '_sws_src', $url );
		return (int) $id;
	}

	/** Ενημέρωση μόνο τιμών/stock για όλα τα ήδη εισηγμένα προϊόντα (σε batches). */
	public static function sync_live_batch( $offset, $limit = 40, $refresh = false ) {
		$live = SWS_Catalog::live( $refresh );
		$s    = SWS_Settings::get();
		$q    = new WP_Query( array(
			'post_type'      => 'product',
			'post_status'    => 'any',
			'fields'         => 'ids',
			'posts_per_page' => $limit,
			'offset'         => $offset,
			'orderby'        => 'ID',
			'order'          => 'ASC',
			'meta_key'       => '_sws_ref',
		) );
		foreach ( $q->posts as $pid ) {
			$prod = wc_get_product( $pid );
			if ( ! $prod ) {
				continue;
			}
			$ref = $prod->get_meta( '_sws_ref' );
			if ( $prod->is_type( 'variable' ) ) {
				foreach ( $prod->get_children() as $vid ) {
					$v = wc_get_product( $vid );
					if ( $v ) {
						self::apply_live( $v, $v->get_sku(), $ref, $live, $s['markup'] );
						$v->save();
					}
				}
				WC_Product_Variable::sync( $pid );
			} else {
				self::apply_live( $prod, $prod->get_sku(), $ref, $live, $s['markup'] );
				$prod->save();
			}
		}
		return array( 'total' => (int) $q->found_posts, 'done' => min( $offset + $limit, (int) $q->found_posts ) );
	}
}
