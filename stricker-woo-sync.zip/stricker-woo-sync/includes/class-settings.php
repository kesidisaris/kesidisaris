<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class SWS_Settings {

	const OPTION = 'sws_settings';

	public static function defaults() {
		return array(
			'access_key'    => '',
			'protocol'      => 'https',
			'language'      => 'EN',
			'markup'        => 0,
			'import_images' => 1,
			'status'        => 'publish',
			'color_label'   => 'Χρώμα',
		);
	}

	public static function languages() {
		return array( 'NL', 'EN', 'FR', 'DE', 'IT', 'PL', 'PT', 'RU', 'ES', 'CZ', 'SK', 'BG', 'HR', 'DK', 'FI', 'GR', 'HU', 'NO', 'RO', 'RS', 'SE', 'UA' );
	}

	public static function get() {
		return wp_parse_args( (array) get_option( self::OPTION, array() ), self::defaults() );
	}

	public static function sanitize( $in ) {
		$d   = self::defaults();
		$out = array();
		$out['access_key']    = sanitize_text_field( $in['access_key'] ?? '' );
		$out['protocol']      = ( $in['protocol'] ?? 'https' ) === 'http' ? 'http' : 'https';
		$out['language']      = in_array( $in['language'] ?? '', self::languages(), true ) ? $in['language'] : $d['language'];
		$out['markup']        = (float) ( $in['markup'] ?? 0 );
		$out['import_images'] = empty( $in['import_images'] ) ? 0 : 1;
		$out['status']        = in_array( $in['status'] ?? '', array( 'publish', 'draft', 'pending' ), true ) ? $in['status'] : 'publish';
		$out['color_label']   = sanitize_text_field( $in['color_label'] ?? '' ) ?: $d['color_label'];
		delete_transient( 'sws_token' );
		return $out;
	}
}
