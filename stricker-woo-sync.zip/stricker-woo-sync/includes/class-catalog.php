<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Κατεβάζει και κρατά cache (αρχεία JSON στο uploads) του καταλόγου Stricker:
 *  - catalog.json : προϊόντα, optionals (χρώματα/SKU), δέντρο κατηγοριών
 *  - live.json    : stock και τιμές (ανανεώνονται πιο συχνά)
 */
class SWS_Catalog {

	const REF_KEYS = array( 'ProdReference', 'ProductReference', 'Reference' );

	private static $refpaths = array();

	public static function dir() {
		$u = wp_upload_dir();
		$d = $u['basedir'] . '/stricker-sync';
		if ( ! file_exists( $d ) ) {
			wp_mkdir_p( $d );
			file_put_contents( $d . '/index.php', "<?php // silence\n" );
			file_put_contents( $d . '/.htaccess', "Deny from all\n" );
		}
		return $d;
	}

	private static function read( $name ) {
		$f = self::dir() . '/' . $name;
		if ( ! file_exists( $f ) ) {
			return null;
		}
		$d = json_decode( file_get_contents( $f ), true );
		return is_array( $d ) ? $d : null;
	}

	private static function write( $name, $data ) {
		file_put_contents( self::dir() . '/' . $name, wp_json_encode( $data ) );
	}

	public static function get( $refresh = false ) {
		static $mem = null;
		if ( $refresh ) {
			$mem = self::build();
			return $mem;
		}
		if ( null === $mem ) {
			$mem = self::read( 'catalog.json' ) ?: new WP_Error( 'sws_nocache', 'Ο κατάλογος δεν έχει φορτωθεί ακόμη.' );
		}
		return $mem;
	}

	public static function build() {
		@set_time_limit( 0 );
		wp_raise_memory_limit( 'admin' );
		$api = new SWS_API();

		$raw_p = $api->get( 'products' );
		if ( is_wp_error( $raw_p ) ) {
			return $raw_p;
		}
		$raw_o = $api->get( 'optionals' );
		if ( is_wp_error( $raw_o ) ) {
			return $raw_o;
		}
		$raw_t = $api->get( 'productsTree' );
		if ( is_wp_error( $raw_t ) ) {
			return $raw_t;
		}

		// Προϊόντα
		$products = array();
		foreach ( SWS_Util::extract_list( $raw_p ) as $it ) {
			$ref = SWS_Util::pick( $it, self::REF_KEYS );
			if ( '' === $ref ) {
				continue;
			}
			$products[ $ref ] = array(
				'ref'    => $ref,
				'name'   => SWS_Util::pick( $it, array( 'Name', 'ProductName', 'ShortName', 'Title' ), $ref ),
				'short'  => SWS_Util::pick( $it, array( 'ShortDescription', 'ShortDesc' ) ),
				'desc'   => SWS_Util::pick( $it, array( 'Description', 'LongDescription', 'DescriptionLong' ) ),
				'brand'  => SWS_Util::pick( $it, array( 'BrandName', 'Brand' ) ),
				'cat'    => SWS_Util::pick( $it, array( 'CategoryName', 'Category', 'ProductType', 'Type' ) ),
				'images' => SWS_Util::images( $it ),
			);
		}

		// Optionals (SKU / χρώμα / εικόνα)
		$optionals = array();
		foreach ( SWS_Util::extract_list( $raw_o ) as $it ) {
			$sku = SWS_Util::pick( $it, array( 'Sku', 'SKU' ) );
			if ( '' === $sku ) {
				continue;
			}
			$ref = SWS_Util::pick( $it, array( 'ProdReference', 'ProductReference' ) );
			if ( '' === $ref ) {
				$ref = explode( '-', $sku )[0];
			}
			$img = SWS_Util::images( $it );
			$optionals[ $ref ][] = array(
				'sku'    => $sku,
				'color'  => SWS_Util::pick( $it, array( 'ColorDesc', 'ColorName', 'ColorDescription', 'Color', 'Colour', 'ColorDesc1' ) ),
				'images' => $img,
			);
			// Αν το προϊόν δεν είχε εικόνες, δανείσου από το optional.
			if ( isset( $products[ $ref ] ) && ! $products[ $ref ]['images'] && $img ) {
				$products[ $ref ]['images'] = $img;
			}
		}

		// Δέντρο κατηγοριών
		self::$refpaths = array();
		$root = array( 'name' => 'root', 'children' => array(), 'refs' => array() );
		self::walk( $raw_t, $root, array() );
		$tree = $root['children'];

		// Fallback: ομαδοποίηση με βάση το πεδίο κατηγορίας του προϊόντος.
		if ( ! self::count_refs( $tree ) ) {
			$groups = array();
			foreach ( $products as $ref => $p ) {
				$n = $p['cat'] ?: 'Χωρίς κατηγορία';
				$groups[ $n ]['name']     = $n;
				$groups[ $n ]['children'] = array();
				$groups[ $n ]['refs'][]   = $ref;
				self::$refpaths[ $ref ][] = array( $n );
			}
			$tree = array_values( $groups );
		}

		$data = array(
			'built'     => time(),
			'products'  => $products,
			'optionals' => $optionals,
			'tree'      => $tree,
			'refpaths'  => self::$refpaths,
		);
		self::write( 'catalog.json', $data );
		return $data;
	}

	private static function count_refs( $nodes ) {
		$n = 0;
		foreach ( $nodes as $c ) {
			$n += count( $c['refs'] ) + self::count_refs( $c['children'] );
		}
		return $n;
	}

	/** Διασχίζει αναδρομικά το JSON του productsTree. */
	private static function walk( $node, &$cat, $path ) {
		if ( ! is_array( $node ) ) {
			return;
		}
		if ( SWS_Util::is_list( $node ) ) {
			foreach ( $node as $n ) {
				self::walk( $n, $cat, $path );
			}
			return;
		}
		$ref = SWS_Util::pick( $node, self::REF_KEYS );
		if ( '' !== $ref ) {
			$cat['refs'][]            = $ref;
			self::$refpaths[ $ref ][] = $path;
			return;
		}
		$has_children = false;
		foreach ( $node as $v ) {
			if ( is_array( $v ) && $v ) {
				$has_children = true;
				break;
			}
		}
		$name = SWS_Util::pick( $node, array( 'Name', 'CategoryName', 'Description', 'Title', 'Label' ) );
		if ( '' !== $name && $has_children ) {
			$new = array( 'name' => $name, 'children' => array(), 'refs' => array() );
			foreach ( $node as $v ) {
				if ( is_array( $v ) ) {
					self::walk( $v, $new, array_merge( $path, array( $name ) ) );
				}
			}
			$new['refs'] = array_values( array_unique( $new['refs'] ) );
			$cat['children'][] = $new;
			return;
		}
		foreach ( $node as $v ) {
			if ( is_array( $v ) ) {
				self::walk( $v, $cat, $path );
			}
		}
	}

	/** Stock + τιμές. */
	public static function live( $refresh = false ) {
		$cached = self::read( 'live.json' );
		if ( ! $refresh && $cached && ( time() - ( $cached['built'] ?? 0 ) ) < 15 * MINUTE_IN_SECONDS ) {
			return $cached;
		}
		$api  = new SWS_API();
		$live = array( 'built' => time(), 'stocks' => array(), 'prices' => array() );

		$st = $api->get( 'stocks' );
		if ( ! is_wp_error( $st ) ) {
			foreach ( SWS_Util::extract_list( $st ) as $it ) {
				$sku = SWS_Util::pick( $it, array( 'Sku', 'SKU', 'Reference' ) );
				$qty = SWS_Util::pick( $it, array( 'Quantity', 'Stock', 'Qty', 'AvailableQuantity', 'StockQuantity' ), null );
				if ( $sku && null !== $qty ) {
					$live['stocks'][ $sku ] = (int) $qty;
				}
			}
		}
		$pr = $api->get( 'prices' );
		if ( ! is_wp_error( $pr ) ) {
			foreach ( SWS_Util::extract_list( $pr ) as $it ) {
				$key   = SWS_Util::pick( $it, array( 'Sku', 'SKU' ) ) ?: SWS_Util::pick( $it, self::REF_KEYS );
				$price = SWS_Util::num( SWS_Util::pick( $it, array( 'Price', 'CatalogPrice', 'UnitPrice', 'Value', 'Price1' ), null ) );
				if ( $key && null !== $price && ! isset( $live['prices'][ $key ] ) ) {
					$live['prices'][ $key ] = $price;
				}
			}
		}
		if ( $live['stocks'] || $live['prices'] || ! $cached ) {
			self::write( 'live.json', $live );
			return $live;
		}
		return $cached;
	}
}
