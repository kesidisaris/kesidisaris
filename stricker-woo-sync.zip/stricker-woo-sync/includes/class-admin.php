<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class SWS_Admin {

	const CAP = 'manage_woocommerce';

	public static function init() {
		add_action( 'admin_menu', array( __CLASS__, 'menu' ) );
		add_action( 'admin_init', function () {
			register_setting( 'sws', SWS_Settings::OPTION, array( 'sanitize_callback' => array( 'SWS_Settings', 'sanitize' ) ) );
		} );
		add_action( 'admin_enqueue_scripts', array( __CLASS__, 'assets' ) );
		foreach ( array( 'catalog', 'import', 'sync_live', 'debug' ) as $a ) {
			add_action( 'wp_ajax_sws_' . $a, array( __CLASS__, 'ajax_' . $a ) );
		}
	}

	public static function menu() {
		add_submenu_page( 'woocommerce', 'Stricker Sync', 'Stricker Sync', self::CAP, 'stricker-sync', array( __CLASS__, 'page' ) );
	}

	public static function assets( $hook ) {
		if ( 'woocommerce_page_stricker-sync' !== $hook ) {
			return;
		}
		wp_enqueue_style( 'sws-admin', SWS_URL . 'assets/admin.css', array(), SWS_VERSION );
		wp_enqueue_script( 'sws-admin', SWS_URL . 'assets/admin.js', array( 'jquery' ), SWS_VERSION, true );
		wp_localize_script( 'sws-admin', 'SWS', array(
			'ajax'  => admin_url( 'admin-ajax.php' ),
			'nonce' => wp_create_nonce( 'sws' ),
		) );
	}

	/* ---------------------------------------------------------------- Pages */

	public static function page() {
		$tab  = isset( $_GET['tab'] ) ? sanitize_key( $_GET['tab'] ) : 'catalog';
		$tabs = array( 'catalog' => 'Κατάλογος & Συγχρονισμός', 'settings' => 'Ρυθμίσεις', 'debug' => 'Διαγνωστικά' );
		echo '<div class="wrap sws"><h1>Stricker Sync</h1><nav class="nav-tab-wrapper">';
		foreach ( $tabs as $k => $label ) {
			printf( '<a class="nav-tab %s" href="%s">%s</a>', $tab === $k ? 'nav-tab-active' : '', esc_url( admin_url( 'admin.php?page=stricker-sync&tab=' . $k ) ), esc_html( $label ) );
		}
		echo '</nav>';
		call_user_func( array( __CLASS__, 'tab_' . ( isset( $tabs[ $tab ] ) ? $tab : 'catalog' ) ) );
		echo '</div>';
	}

	private static function tab_settings() {
		$s = SWS_Settings::get();
		$o = SWS_Settings::OPTION;
		?>
		<form method="post" action="options.php">
			<?php settings_fields( 'sws' ); ?>
			<table class="form-table">
				<tr><th>Access Key</th><td><input type="password" class="regular-text" name="<?php echo $o; ?>[access_key]" value="<?php echo esc_attr( $s['access_key'] ); ?>" autocomplete="off"></td></tr>
				<tr><th>Πρωτόκολλο</th><td><select name="<?php echo $o; ?>[protocol]">
					<option value="https" <?php selected( $s['protocol'], 'https' ); ?>>HTTPS</option>
					<option value="http" <?php selected( $s['protocol'], 'http' ); ?>>HTTP</option></select></td></tr>
				<tr><th>Γλώσσα καταλόγου</th><td><select name="<?php echo $o; ?>[language]">
					<?php foreach ( SWS_Settings::languages() as $l ) : ?>
						<option <?php selected( $s['language'], $l ); ?>><?php echo esc_html( $l ); ?></option>
					<?php endforeach; ?></select></td></tr>
				<tr><th>Προσαύξηση τιμής (%)</th><td><input type="number" step="0.01" name="<?php echo $o; ?>[markup]" value="<?php echo esc_attr( $s['markup'] ); ?>"><p class="description">Εφαρμόζεται πάνω στην τιμή καταλόγου (CatalogPrices) κατά την εισαγωγή/ενημέρωση.</p></td></tr>
				<tr><th>Κατάσταση νέων προϊόντων</th><td><select name="<?php echo $o; ?>[status]">
					<option value="publish" <?php selected( $s['status'], 'publish' ); ?>>Δημοσιευμένο</option>
					<option value="draft" <?php selected( $s['status'], 'draft' ); ?>>Πρόχειρο</option>
					<option value="pending" <?php selected( $s['status'], 'pending' ); ?>>Σε αναμονή</option></select></td></tr>
				<tr><th>Εικόνες</th><td><label><input type="checkbox" name="<?php echo $o; ?>[import_images]" value="1" <?php checked( $s['import_images'] ); ?>> Λήψη εικόνων στη βιβλιοθήκη πολυμέσων (πιο αργή εισαγωγή)</label></td></tr>
				<tr><th>Όνομα χαρακτηριστικού χρώματος</th><td><input type="text" name="<?php echo $o; ?>[color_label]" value="<?php echo esc_attr( $s['color_label'] ); ?>"></td></tr>
			</table>
			<?php submit_button(); ?>
		</form>
		<?php
	}

	private static function tab_catalog() {
		$s = SWS_Settings::get();
		if ( '' === $s['access_key'] ) {
			echo '<p>Ορίστε πρώτα το Access Key στις <a href="' . esc_url( admin_url( 'admin.php?page=stricker-sync&tab=settings' ) ) . '">Ρυθμίσεις</a>.</p>';
			return;
		}
		?>
		<div class="sws-toolbar">
			<button class="button" id="sws-load">Φόρτωση / Ανανέωση καταλόγου</button>
			<span id="sws-built"></span>
			<span class="sws-spacer"></span>
			<button class="button" id="sws-sync-live" title="Ενημερώνει τιμές και stock για όλα τα ήδη εισηγμένα προϊόντα">Ενημέρωση τιμών &amp; stock εισηγμένων</button>
		</div>
		<div id="sws-app" style="display:none">
			<div class="sws-cols">
				<div class="sws-tree-wrap">
					<h3>Κατηγορίες</h3>
					<div id="sws-tree"></div>
				</div>
				<div class="sws-list-wrap">
					<div class="sws-list-head">
						<input type="search" id="sws-search" placeholder="Αναζήτηση σε όλα τα προϊόντα (όνομα ή κωδικός)…">
						<button class="button" id="sws-sel-visible">Επιλογή εμφανιζόμενων</button>
						<button class="button" id="sws-clear">Καθαρισμός επιλογής</button>
					</div>
					<div id="sws-list-title"></div>
					<div id="sws-list"></div>
				</div>
			</div>
			<div class="sws-footer">
				<button class="button button-primary button-hero" id="sws-import" disabled>Συγχρονισμός επιλεγμένων (0)</button>
				<div id="sws-progress"><div></div></div>
				<pre id="sws-log"></pre>
			</div>
		</div>
		<?php
	}

	private static function tab_debug() {
		echo '<p>Δείγμα της ωμής απάντησης κάθε endpoint (αν τα προϊόντα δεν διαβάζονται σωστά, στείλτε μου αυτό το αποτέλεσμα για να προσαρμόσω την αντιστοίχιση πεδίων).</p><p>';
		foreach ( array( 'authenticate' => 'Έλεγχος σύνδεσης', 'productsTree' => 'productsTree', 'products' => 'products', 'optionals' => 'optionals', 'stocks' => 'stocks', 'prices' => 'CatalogPrices' ) as $k => $l ) {
			printf( '<button class="button sws-dbg" data-ep="%s">%s</button> ', esc_attr( $k ), esc_html( $l ) );
		}
		echo '</p><pre id="sws-dbg-out"></pre>';
	}

	/* ---------------------------------------------------------------- AJAX */

	private static function guard() {
		check_ajax_referer( 'sws', '_n' );
		if ( ! current_user_can( self::CAP ) ) {
			wp_send_json_error( 'Δεν επιτρέπεται.', 403 );
		}
	}

	public static function ajax_catalog() {
		self::guard();
		$refresh = ! empty( $_POST['refresh'] );
		$cat     = SWS_Catalog::get( $refresh );
		if ( is_wp_error( $cat ) ) {
			if ( ! $refresh && 'sws_nocache' === $cat->get_error_code() ) {
				$cat = SWS_Catalog::get( true );
			}
			if ( is_wp_error( $cat ) ) {
				wp_send_json_error( $cat->get_error_message() );
			}
		}
		$prods = array();
		foreach ( $cat['products'] as $ref => $p ) {
			$prods[ $ref ] = array( $p['name'], $p['images'][0] ?? '', count( $cat['optionals'][ $ref ] ?? array() ) );
		}
		wp_send_json_success( array(
			'built'    => wp_date( 'd/m/Y H:i', $cat['built'] ),
			'tree'     => $cat['tree'],
			'products' => $prods,
		) );
	}

	public static function ajax_import() {
		self::guard();
		@set_time_limit( 300 );
		$refs = isset( $_POST['refs'] ) ? array_map( 'sanitize_text_field', (array) wp_unslash( $_POST['refs'] ) ) : array();
		$out  = array();
		foreach ( $refs as $ref ) {
			$out[] = SWS_Importer::import( $ref );
		}
		wp_send_json_success( array( 'results' => $out ) );
	}

	public static function ajax_sync_live() {
		self::guard();
		@set_time_limit( 300 );
		$offset = (int) ( $_POST['offset'] ?? 0 );
		wp_send_json_success( SWS_Importer::sync_live_batch( $offset, 40, 0 === $offset ) );
	}

	public static function ajax_debug() {
		self::guard();
		$ep  = sanitize_text_field( $_POST['ep'] ?? '' );
		$api = new SWS_API();
		if ( 'authenticate' === $ep ) {
			$t = $api->token( true );
			wp_send_json_success( is_wp_error( $t ) ? 'ΣΦΑΛΜΑ: ' . $t->get_error_message() : 'OK – token: ' . $t );
		}
		if ( ! in_array( $ep, array( 'productsTree', 'products', 'optionals', 'stocks', 'prices' ), true ) ) {
			wp_send_json_error( 'Άγνωστο endpoint' );
		}
		$r = $api->get( $ep );
		if ( is_wp_error( $r ) ) {
			wp_send_json_error( $r->get_error_message() );
		}
		$list = SWS_Util::extract_list( $r );
		$sample = $list ? array_slice( $list, 0, 2 ) : $r;
		wp_send_json_success( 'Εγγραφές: ' . count( $list ) . "\n\n" . substr( wp_json_encode( $sample, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES ), 0, 6000 ) );
	}
}
